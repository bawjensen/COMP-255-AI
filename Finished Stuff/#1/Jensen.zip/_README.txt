(Note: I've never written a README.txt before so I'm giving it my best shot)

=== Program Overview ===

This program is a class based program written in Python 2.7.3, for the use of printing a list of anagrams to the console given an input word and the name of a .txt file to use as a dictionary. The format of the output is simply "[#anagramsFound]: anagram."

=== API ===

This program is implemented by importing "Anagram", from which you can call the Anagram.Anagram(str, str) passing two string arguments, the first being the anagram word and the second the dictionary name. This will create an instance of the Anagram class, on which you can call the method .find_anagrams() to find and print all anagrams of the input word to the console, in the stated format.

Module: Anagram
Methods: Anagram(), find_anagrams()

Anagram() parameters:
1. Str: Word to be anagrammed
2. Str: Name of plain-text dictionary file

find_anagrams() parameters: None

